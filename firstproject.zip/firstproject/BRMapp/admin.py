from django.contrib import admin
from BRMapp.models import BRMuser

admin.site.register(BRMuser)
