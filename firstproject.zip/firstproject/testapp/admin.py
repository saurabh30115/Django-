from django.contrib import admin
from testapp.models import Employee
admin.site.register(Employee)
